
public class Assignment02_Ex9 {

	public static void main(String[] args) {
		System.out.println("The statement " + "\"System.out.println(\"\\\"\\tTest\\\\\\\\\\rIt\\'\")\"" + "prints:");
		System.out.println("\"\tTest\\\\\rIt\'");
		
		System.out.print("When \"r\" is replaced with \"n\". ");
		System.out.println("The statement " + "\"System.out.println(\"\\\"\\tTest\\\\\\\\\\nIt\\'\")\"" + "prints:");
		System.out.println("\"\tTest\\\\\nIt\'");
		
		System.out.println("No, replaceing r with n, does not make a difference in what was displayed.");
	}

}
